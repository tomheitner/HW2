/*

  File: party.h

  Abstract:

    Party handling interface

*/


#ifndef _PARTY_H_
#define _PARTY_H_

void PrintResult();
void FreeParties();
char* AddVote(char* pPartyName);




#endif /* _PARTY_H_ */
